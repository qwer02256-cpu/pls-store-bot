import base64, hashlib, io, json, math, shutil, subprocess, zipfile
from pathlib import Path
import cairosvg
from PIL import Image, ImageDraw, ImageFont
ROOT=Path(__file__).resolve().parent
SRC=Path('/workspace/emoji-pack-build/lucide/package')
for d in ['webm','png','svg']: (ROOT/d).mkdir(exist_ok=True)
items=[
('profile','user-round','Профиль','👤','pulse'),('shop','shopping-bag','Магазин','🛍','bob'),('plugins','puzzle','Плагины','🧩','tilt'),('purchases','shopping-cart','Покупки','🛒','slide'),('support','headphones','Поддержка','🎧','pulse'),('faq','circle-help','FAQ','❓','tilt'),('documents','files','Документы','📄','bob'),('language','languages','Язык','🌐','tilt'),('settings','settings','Настройки','⚙️','rotate'),('api','code-xml','API','💻','pulse'),('wallet','wallet','Баланс','👛','pulse'),('topup','wallet-cards','Пополнение','💳','bob'),('ruble','russian-ruble','Рубль','💰','tilt'),('card','credit-card','Карта','💳','slide'),('receipt','receipt','Чек','🧾','bob'),('gift','gift','Подарок','🎁','tilt'),('promo','ticket','Промокод','🎟','pulse'),('referrals','users','Рефералы','👥','pulse'),('back','arrow-left','Назад','⬅️','left'),('forward','arrow-right','Вперёд','➡️','right'),('home','house','Домой','🏠','bob'),('search','search','Поиск','🔍','orbit'),('refresh','refresh-cw','Обновление','🔄','rotate'),('download','download','Скачивание','⬇️','down'),('link','link','Ссылка','🔗','tilt'),('bell','bell','Уведомления','🔔','ring'),('success','circle-check','Успешно','✅','pulse'),('error','circle-x','Ошибка','❌','shake'),('waiting','clock','Ожидание','⏳','tilt'),('favorite','star','Избранное','⭐','pulse')]
fontpath='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
font=ImageFont.truetype(fontpath,13)
frames_by_icon=[]; manifest=[]
for n,(key,icon,label,emoji,motion) in enumerate(items,1):
 stem=f'{n:02d}_{key}'
 svg=((ROOT/'svg'/f'{stem}.svg').read_text() if (ROOT/'svg'/f'{stem}.svg').exists() else (SRC/'icons'/f'{icon}.svg').read_text()).replace('currentColor','#ffffff').replace('stroke-width="2"','stroke-width="2.2"')
 (ROOT/'svg'/f'{stem}.svg').write_text(svg)
 base=Image.open(io.BytesIO(cairosvg.svg2png(bytestring=svg.encode(),output_width=300,output_height=300))).convert('RGBA')
 frames=[]
 for f in range(60):
  t=2*math.pi*f/60; scale=1.; angle=0.;dx=dy=0.
  if motion=='pulse':scale=1-.065*(1-math.cos(t))
  elif motion=='bob':dy=11*math.sin(t)
  elif motion=='tilt':angle=7*math.sin(t)
  elif motion=='slide':dx=10*math.sin(t)
  elif motion=='left':dx=-16*math.sin(t)
  elif motion=='right':dx=16*math.sin(t)
  elif motion=='down':dy=15*math.sin(t)
  elif motion=='rotate':angle=-360*f/60
  elif motion=='orbit':dx=8*math.sin(t);dy=8*(1-math.cos(t))-8
  elif motion=='ring':angle=12*math.sin(3*t)*(1-math.cos(t))/2
  elif motion=='shake':dx=9*math.sin(3*t)*(1-math.cos(t))/2
  size=round(300*scale)
  img=base.resize((size,size),Image.Resampling.LANCZOS).rotate(angle,Image.Resampling.BICUBIC,expand=True)
  canvas=Image.new('RGBA',(400,400))
  canvas.alpha_composite(img,((400-img.width)//2+round(dx),(400-img.height)//2+round(dy)))
  canvas=canvas.resize((100,100),Image.Resampling.LANCZOS)
  # Preserve exclusively white RGB; all edge smoothing lives in alpha.
  alpha=canvas.getchannel('A')
  # A diagonal white highlight travels over the icon, clipped to its silhouette.
  # Alpha modulation preserves pure white RGB without a colored sheen or halo.
  sweep = -85 + 250 * ((f - 6) / 46)
  mask = Image.new('L', (100,100))
  mask.putdata([
      round(255 * (0.70 + 0.30 * math.exp(-((x - 0.38*y - sweep) / 7.0)**2)))
      for y in range(100) for x in range(100)
  ])
  from PIL import ImageChops
  alpha=ImageChops.multiply(alpha, mask).point(lambda a: 0 if a < 8 else a)
  canvas=Image.merge('RGBA',(Image.new('L',(100,100),255),)*3+(alpha,))
  frames.append(canvas)
 frames[0].save(ROOT/'png'/f'{stem}.png')
 proc=subprocess.Popen(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pixel_format','rgba','-video_size','100x100','-framerate','30','-i','pipe:0','-an','-c:v','libvpx-vp9','-pix_fmt','yuva420p','-b:v','0','-lossless','1','-deadline','good','-cpu-used','4','-threads','2','-auto-alt-ref','0','-metadata:s:v:0','alpha_mode=1',str(ROOT/'webm'/f'{stem}.webm')],stdin=subprocess.PIPE)
 proc.communicate(b''.join(im.tobytes() for im in frames))
 assert proc.returncode==0
 frames_by_icon.append(frames)
 manifest.append(dict(number=n,name=key,label=label,emoji=emoji,animation=motion+"+shine",file=f'webm/{stem}.webm'))
 print(f'{n:02d}/30 {key}',flush=True)
preview=[]
for f in range(0,60,2):
 sheet=Image.new('RGB',(700,900),'#18222d');d=ImageDraw.Draw(sheet)
 d.text((22,15),'PLS Store · White Emoji · 30',font=ImageFont.truetype(fontpath,23),fill='white')
 for i,frames in enumerate(frames_by_icon):
  x=10+(i%5)*140;y=60+(i//5)*138
  sheet.paste(frames[f],(x+20,y),frames[f])
  label=f'{i+1:02d} {items[i][2]}'
  bbox=d.textbbox((0,0),label,font=font)
  d.text((x+(140-(bbox[2]-bbox[0]))//2,y+107),label,font=font,fill='#ffffff')
 preview.append(sheet)
preview[0].save(ROOT/'preview.png')
preview[0].save(ROOT/'preview.gif',save_all=True,append_images=preview[1:],duration=[70,70,60]*10,loop=0,optimize=False)
(ROOT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
if not (ROOT/'LICENSE-Lucide.txt').exists(): shutil.copy(SRC/'LICENSE',ROOT/'LICENSE-Lucide.txt')
(ROOT/'README.txt').write_text('''PLS Store — White Emoji, 30 анимированных эмодзи

Файлы для Telegram: папка webm. Каждый файл: VP9, 100×100, 30 кадров/с,
2 секунды, прозрачный фон, без звука. RGB значков — белый. По значкам проходит диагональный белый блик.
PNG — статичные версии. SVG — векторные исходники.
preview.gif — анимированное превью на тёмной подложке (подложка только в превью).
manifest.json — порядок, названия и соответствующие обычные эмодзи.

Публикация:
1. Откройте официальный @Stickers в Telegram.
2. Отправьте /newemojipack, выберите тип Video / Видео.
3. Назовите набор PLS Store White.
4. Загружайте файлы webm как файлы/документы, без преобразования в видео.
5. Каждому назначайте соответствующий обычный эмодзи из manifest.json.
6. Отправьте /publish и задайте свободное короткое имя набора.
Интерфейс @Stickers может отличаться; следуйте его текущим подсказкам.

Набор ещё не опубликован. Приём файлов сервером Telegram требует проверки
при загрузке в @Stickers; локальные проверки не заменяют эту проверку.
После публикации можно получить custom_emoji_id и настроить их в боте.
Применение Premium Emoji зависит от действующих ограничений Telegram.

Контурные формы: Lucide 0.468.0 (ISC), лицензия приложена.
Анимация и сборка: подготовлены для PLS Store.
''')
builder = Path('/workspace/emoji-pack-build/build.py')
if builder.exists() and builder.resolve() != (ROOT/'build.py').resolve():
    content=builder.read_text().replace("ROOT=Path(__file__).resolve().parent", "ROOT=Path(__file__).resolve().parent")
    (ROOT/'build.py').write_text(content)
(ROOT/'requirements-build.txt').write_text('cairosvg==2.9.1\npillow==13.0.0\n')
with zipfile.ZipFile(ROOT.parent/'PLS-Store-White-Emoji-30.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(ROOT.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(ROOT.parent))
print('Archive ready',flush=True)
